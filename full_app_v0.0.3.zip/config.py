# config.py: Configuración segura de la aplicación
import os
from dotenv import load_dotenv
from urllib.parse import quote_plus  # Para codificar caracteres especiales

load_dotenv()  # Carga las variables de entorno

class Config:
    # Configuración básica
    SECRET_KEY = os.getenv('SECRET_KEY', 'clave_por_defecto_no_segura_cambiar')
    DEFAULT_THEME = os.getenv('DEFAULT_THEME', 'dark')
    DB_RESETEADA = os.getenv('DB_RESETEADA', 'False') == 'True'

    # Configuración de MySQL con mysql-connector-python
    DB_HOST = os.getenv('DB_HOST')
    DB_USER = os.getenv('DB_USER')
    DB_PASSWORD = os.getenv('DB_PASSWORD')
    DB_NAME = os.getenv('DB_NAME')
    DB_PORT = int(os.getenv('DB_PORT', '3306'))
    
    # Construcción segura de la URI
    # Codificar contraseña para caracteres especiales
    encoded_password = quote_plus(DB_PASSWORD) if DB_PASSWORD else ''
    
    SQLALCHEMY_DATABASE_URI = (
        f"mysql+mysqlconnector://{DB_USER}:{encoded_password}"
        f"@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    )
    
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_recycle': 299,
        'pool_pre_ping': True,
        'connect_args': {
            'connect_timeout': 5,
            'ssl_disabled': True
        }
    }