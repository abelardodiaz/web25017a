# app/utils/token_obtener_api.py
import requests
from datetime import datetime, timedelta, timezone
from app import db
from app.models import SyscomCredential
from sqlalchemy.exc import SQLAlchemyError
import logging

logger = logging.getLogger(__name__)

TOKEN_URL = "https://developers.syscom.mx/oauth/token"

def request_token(cred: SyscomCredential) -> bool:
    try:
        # ... código de solicitud existente ...
        db.session.commit()
        return True
    except SQLAlchemyError as e:
        logger.error(f"DB error updating token: {str(e)}")
        db.session.rollback()
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
    return False

def get_valid_token(grace_days: int = 0):
    # Usar updated_at en lugar de created_at
    cred = SyscomCredential.query.order_by(
        SyscomCredential.updated_at.desc()
    ).first()
    
    if cred and cred.token and not cred.is_expired(grace_days):
        return cred, cred.token
    return None, None