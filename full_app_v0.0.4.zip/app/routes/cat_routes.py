# app/routes/cat_routes.py
from flask import Blueprint, render_template

catalogo_bp = Blueprint('catalogo', __name__, url_prefix='/catalogo')

@catalogo_bp.route('/mantenimiento')
def mantenimiento():
    return render_template('cat/cat_mantenimiento.html')

@catalogo_bp.route('/sincronizar')
def sincronizar():
    return render_template('cat/cat_sinc.html')

@catalogo_bp.route('/alta')
def alta():
    return render_template('cat/cat_alta.html')
